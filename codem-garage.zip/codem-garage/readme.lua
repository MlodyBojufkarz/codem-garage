 Thank you as CODEM for purchasing the script before starting the process.

 1 - if you have sql data don't install sql data in folder. sqls are for ESX users only

 2 -  is necessary  vehicles sql and owned_vehicles jsut ESX users only

3 https://cdn.discordapp.com/attachments/653676380739076099/968261796244885574/unknown.png -- You can write the vehicles that you do not want to be sold in this section.